package com.dicoding.academy.githubuser.ui.main

import android.os.Bundle
import com.dicoding.academy.githubuser.databinding.ActivityMainBinding
import com.dicoding.academy.githubuser.ui.baseUI.BaseActivity

class MainActivity : BaseActivity<ActivityMainBinding>(
    ActivityMainBinding::inflate
) {
    override fun initView(savedInstanceState: Bundle?) {

    }
}