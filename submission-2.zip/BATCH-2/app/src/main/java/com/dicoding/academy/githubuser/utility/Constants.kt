package com.dicoding.academy.githubuser.utility

object Constants {
    const val COUNT_OF_PER_PAGE = 5
    const val USER_PAGING_STARTING_PAGE_INDEX = 1
}